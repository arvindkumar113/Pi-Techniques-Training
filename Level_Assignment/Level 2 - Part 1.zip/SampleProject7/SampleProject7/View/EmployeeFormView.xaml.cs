﻿using System.Windows;
namespace SampleProject7.View
{
    /// <summary>
    /// Interaction logic for EmployeeForm.xaml
    /// </summary>
    public partial class EmployeeFormView : Window
    {
        public EmployeeFormView()
        {
            InitializeComponent();
        }
    }
}
