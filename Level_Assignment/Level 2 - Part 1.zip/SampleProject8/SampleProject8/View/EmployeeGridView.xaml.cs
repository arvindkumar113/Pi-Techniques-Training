﻿using System.Windows;

namespace SampleProject8.View
{
    /// <summary>
    /// Interaction logic for EmployeeGridView.xaml
    /// </summary>
    public partial class EmployeeGridView : Window
    {
        public EmployeeGridView()
        {
            InitializeComponent();
        }
    }
}
