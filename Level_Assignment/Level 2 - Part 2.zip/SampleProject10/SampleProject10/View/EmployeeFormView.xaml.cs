﻿using System.Windows;

namespace SampleProject10.View
{
    /// <summary>
    /// Interaction logic for EmployeeFormView.xaml
    /// </summary>
    public partial class EmployeeFormView : Window
    {
        public EmployeeFormView()
        {
            InitializeComponent();
        }
    }
}
