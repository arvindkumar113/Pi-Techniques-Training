﻿using System.Windows;

namespace SampleProject9.View
{
    /// <summary>
    /// Interaction logic for EmployeeGridView.xaml
    /// </summary>
    public partial class EmployeeGridView : Window
    {
        public EmployeeGridView()
        {
            InitializeComponent();
        }
    }
}
