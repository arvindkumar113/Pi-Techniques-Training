﻿using System.Windows;

namespace SampleProject11.View
{
    /// <summary>
    /// Interaction logic for EmployeeFormView.xaml
    /// </summary>
    public partial class EmployeeFormView : Window
    {
        public EmployeeFormView()
        {
            InitializeComponent();
        }
    }
}
