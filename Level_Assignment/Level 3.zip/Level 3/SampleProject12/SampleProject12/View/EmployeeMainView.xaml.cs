﻿using System.Windows;

namespace SampleProject12.View
{
    /// <summary>
    /// Interaction logic for EmployeeMainView.xaml
    /// </summary>
    public partial class EmployeeMainView : Window
    {
        public EmployeeMainView()
        {
            InitializeComponent();
        }
    }
}
