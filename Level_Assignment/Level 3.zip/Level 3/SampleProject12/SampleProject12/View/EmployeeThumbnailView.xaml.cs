﻿using System.Windows.Controls;

namespace SampleProject12.View
{
    /// <summary>
    /// Interaction logic for EmployeeThumbnailView.xaml
    /// </summary>
    public partial class EmployeeThumbnailView : UserControl
    {
        public EmployeeThumbnailView()
        {
            InitializeComponent();
        }
    }
}
